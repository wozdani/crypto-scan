import requests
import os

def get_token_price_usd(symbol):
    print(f"⚠️ get_token_price_usd wyłączony – użyj danych rynkowych")
    return None
