from utils.data_fetchers import build_bybit_symbol_cache

if __name__ == "__main__":
    build_bybit_symbol_cache()
