from utils.coingecko import get_contract

result = get_contract("PEPE")
print(result)
